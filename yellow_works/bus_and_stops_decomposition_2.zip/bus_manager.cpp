#include "bus_manager.h"

void BusManager::AddBus(const string &bus, const vector<string> &stops)
{
    buses_to_stops[bus] = stops;
    for (const string &stop : stops)
    {
        stops_to_buses[stop].push_back(bus);
    }
}

BusesForStopResponse BusManager::GetBusesForStop(const string &stop) const
{
    if (stops_to_buses.count(stop))
    {
        return {stops_to_buses.at(stop)};
    }
    return {};
}

StopsForBusResponse BusManager::GetStopsForBus(const string &bus) const
{
    return StopsForBusResponse{bus, buses_to_stops, stops_to_buses};
}

AllBusesResponse BusManager::GetAllBuses() const
{
    return AllBusesResponse{buses_to_stops};
}