#pragma once
#include <vector>
#include <string>
#include <map>
#include <iostream>

using namespace std;

struct BusesForStopResponse
{
    const vector<string> buses;
};

struct StopsForBusResponse
{
    StopsForBusResponse(const string &ref_bus, const map<string, vector<string>> &ref_buses_to_stops, const map<string, vector<string>> &ref_stops_to_buses)
        : bus(ref_bus),
          buses_to_stops(ref_buses_to_stops),
          stops_to_buses(ref_stops_to_buses) {}

    const string &bus;
    const map<string, vector<string>> &buses_to_stops;
    const map<string, vector<string>> &stops_to_buses;
};

struct AllBusesResponse
{
    AllBusesResponse(const map<string, vector<string>> &ref_buses_to_stops)
        : buses_to_stops(ref_buses_to_stops) {}
    const map<string, vector<string>> &buses_to_stops;
};

ostream &operator<<(ostream &os, const BusesForStopResponse &r);
ostream &operator<<(ostream &os, const StopsForBusResponse &r);
ostream &operator<<(ostream &os, const AllBusesResponse &r);