#pragma once
#include "trans.h"
#include "render.h"

void TestParseAddStopQuery();
void TestParseAddBusQuery();
void TestCalcGeoDistance();
void TestDataBaseCreateInfo();
void TestDataBaseCreateGraph();
void TestMakeRenderSettigs();
void TestCreateMap();
void TestBuildRoute();
void TestParseJson();
void TestParse();
void TestParseRouteQuery();
void Test15Failed();
void TestRender0();
void TestRender1();